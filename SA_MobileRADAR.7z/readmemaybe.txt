############################################
#	Mobile RADAR Map Textures          #
############################################

This pack contains all the RADAR Map Textures from the Mobile versions of Grand Theft Auto: San Andreas, repacked and ready to be used for the PC version. All textures were
exported in the best quality possible from the PVR Cache and then repacked with a more up to date DXT Codec to keep the quality as best as possible.


How to Install:
Use whatever IMG editor you prefer, locate GTA3.IMG in your San Andreas Directory, and then replace all files with the ones provided in this ZIP.

Alternate Method:
Use Mod Loader, drag "RADARtoGTA3IMG" to your modloader folder.

By Ash_735