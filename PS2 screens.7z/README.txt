PS2 screens (30.04.2017)

You'll found two main.scm:
1. In this one, everything that has been reported is present (Life's a beach 4000 points, intro train speed, Black Project alarm sound).
2. It's basically the same as above but without the alarm sound (no complaints from people that don't like it like that).

These changes are not done to be played with keyboard controls.

To really have what I shown in the screenshots, it's better to use PS2 Feels or at least use the american.gxt and follow the instructions of what to disable in GInputSA.ini.

If you really don't want to use PS2 Feels, just download GInputSA and SA classic textures for GInput, but you're warned, it won't be totally the same.