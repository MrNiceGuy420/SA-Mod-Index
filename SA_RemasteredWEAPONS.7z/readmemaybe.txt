############################################
#	Remastered Weapon Icons            #
############################################

This pack contains all weapons from Grand Theft Auto: San Andreas repacked and remastered, using source files from PS2 and Mobile versions of the game, all Weapon Icons have
been recoloured to match their original PS2 counterparts (no more purple hue).
All weapon textures have been sourced from the PS2 files and compressed using a more up to date DXT codec so the quality is slightly better in most cases, and all weapon
muzzle flashes have been compressed using DXT-5 so they retain a quality much closer to the PS2 version instead of the muted PC version. I have provided both original
PS2/PC Blips repacked and Mobile Blips repacked so you can choose which one you prefer visually.


How to Install:
Use whatever IMG editor you prefer, locate GTA3.IMG in your San Andreas Directory, and then replace all files with the ones provided in this ZIP. To get the full benefit of
these remastered weapon icons, you MUST also install SilentPatch for SA (http://gtaforums.com/topic/669045-iiivcsaasi-silentpatch/).

Then choose which Radar BLIP style you prefer (MOBILE or PS2/PC) and drag the hud.txd from the chosen folder to your "models" folder and choose yes when asked.

Alternate Method:
Use Mod Loader, drag "WEAPONStoGTA3IMG" to your modloader folder and then choose which hud.txd you want to copy to "models".

By Ash_735